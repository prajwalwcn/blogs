module.exports=[78431,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_authors_page_actions_0785d7c.js.map