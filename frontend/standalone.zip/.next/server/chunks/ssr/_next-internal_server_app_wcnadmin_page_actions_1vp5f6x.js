module.exports=[33975,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_wcnadmin_page_actions_1vp5f6x.js.map