module.exports=[17328,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_authors_create_page_actions_0dbmp9a.js.map