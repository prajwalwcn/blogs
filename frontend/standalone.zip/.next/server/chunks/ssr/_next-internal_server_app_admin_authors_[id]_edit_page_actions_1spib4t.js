module.exports=[22485,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_authors_%5Bid%5D_edit_page_actions_1spib4t.js.map