module.exports=[41276,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_blogs_%5Bid%5D_page_actions_1sld3t7.js.map