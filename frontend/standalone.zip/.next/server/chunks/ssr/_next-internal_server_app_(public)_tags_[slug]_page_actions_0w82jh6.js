module.exports=[30259,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_tags_%5Bslug%5D_page_actions_0w82jh6.js.map