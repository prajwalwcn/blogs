module.exports=[82624,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_redirects_page_actions_0ua4117.js.map