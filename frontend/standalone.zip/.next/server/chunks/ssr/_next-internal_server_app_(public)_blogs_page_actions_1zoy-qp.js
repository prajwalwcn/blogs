module.exports=[35646,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_blogs_page_actions_1zoy-qp.js.map