module.exports=[28238,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_blogs_%5Bid%5D_edit_page_actions_12rgwil.js.map