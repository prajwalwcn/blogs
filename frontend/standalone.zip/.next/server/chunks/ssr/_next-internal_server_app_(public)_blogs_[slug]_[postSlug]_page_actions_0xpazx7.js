module.exports=[31527,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_blogs_%5Bslug%5D_%5BpostSlug%5D_page_actions_0xpazx7.js.map