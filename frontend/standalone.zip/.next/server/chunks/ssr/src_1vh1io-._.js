module.exports=[72190,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/public/CommentSection.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/public/CommentSection.tsx <module evaluation>","default")},46701,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/public/CommentSection.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/public/CommentSection.tsx","default")},85146,a=>{"use strict";a.i(72190);var b=a.i(46701);a.n(b)},69592,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/public/ShareButtons.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/public/ShareButtons.tsx <module evaluation>","default")},20347,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/public/ShareButtons.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/public/ShareButtons.tsx","default")},37693,a=>{"use strict";a.i(69592);var b=a.i(20347);a.n(b)},45661,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/public/TableOfContents.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/public/TableOfContents.tsx <module evaluation>","default")},29515,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/public/TableOfContents.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/public/TableOfContents.tsx","default")},89848,a=>{"use strict";a.i(45661);var b=a.i(29515);a.n(b)},86398,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/public/CategoryList.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/public/CategoryList.tsx <module evaluation>","default")},79116,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/src/components/public/CategoryList.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/src/components/public/CategoryList.tsx","default")},48013,a=>{"use strict";a.i(86398);var b=a.i(79116);a.n(b)},99793,a=>{"use strict";var b=a.i(7997),c=a.i(95936);a.i(70396);var d=a.i(73727),e=a.i(5246),f=a.i(62284),g=a.i(82001),h=a.i(3236),i=a.i(85146),j=a.i(37693),k=a.i(89848),l=a.i(48013);let m="https://demo.webcreationcanada.com/backend".replace(/\/api\/?$/,"").replace(/\/$/,"");async function n(a){try{let b=await fetch(`${m}/api/blogs/${a}?limit=100`,{next:{revalidate:60},headers:{Accept:"application/json"}});if(!b.ok)return null;return await b.json()}catch{return null}}async function o(){try{let a=await fetch(`${m}/api/categories`,{next:{revalidate:60},headers:{Accept:"application/json"}});if(!a.ok)return[];return(await a.json()).data??[]}catch{return[]}}async function p(a){try{let b=await fetch(`${m}/api/blogs`,{next:{revalidate:60},headers:{Accept:"application/json"}});if(!b.ok)return[];return((await b.json()).data??[]).filter(b=>b.slug!==a).slice(0,4)}catch{return[]}}async function q(){try{let a=await fetch(`${m}/api/blogs`,{next:{revalidate:60},headers:{Accept:"application/json"}});if(!a.ok)return[];return(await a.json()).data??[]}catch{return[]}}async function r(){try{let a=await fetch(`${m}/api/settings`,{next:{revalidate:60},headers:{Accept:"application/json"}});if(!a.ok)return null;return(await a.json()).data??null}catch{return null}}function s(a){if(!a)return"";if(a.startsWith("http://")||a.startsWith("https://"))return a;let b="https://demo.webcreationcanada.com/backend".replace(/\/api\/?$/,"").replace(/\/$/,""),c=a.startsWith("/")?a:`/${a}`;return`${b}${c}`}async function t(){try{let a="https://demo.webcreationcanada.com/backend".replace(/\/api\/?$/,"").replace(/\/$/,""),b=await fetch(`${a}/api/blogs`,{headers:{Accept:"application/json"}});if(!b.ok)return[];return((await b.json()).data??[]).map(a=>({slug:a.slug}))}catch{return[]}}async function u({params:a}){let b=await a,c=await n(b.slug);if(!c)return{};let{blog:d}=c,e=d.seo?.meta,f=d.seo?.og,g=f?.["og:image"]||(d.image?.url?s(d.image.url):"/logo.png"),h=d.author?.name||"Web Creation Nepal";return{title:e?.title||d.name,description:e?.description||d.excerpt||"Web Creation Nepal Blog Channel",keywords:e?.keywords||"",alternates:{canonical:`/blogs/${d.slug}`},openGraph:{title:f?.["og:title"]||d.name,description:f?.["og:description"]||d.excerpt||"",url:`/blogs/${d.slug}`,type:"article",publishedTime:d.created_at||void 0,authors:[h],images:[{url:g,alt:d.image?.alt||d.name}]},twitter:{card:"summary_large_image",title:f?.["og:title"]||d.name,description:f?.["og:description"]||d.excerpt||"",images:[g],creator:"@webcreationnepal"}}}async function v({params:a}){let m=await a,[t,u,w,x,y]=await Promise.all([n(m.slug),o(),p(m.slug),r(),q()]);t||(0,d.notFound)();let{blog:z}=t,A=y.findIndex(a=>a.slug===z.slug),B=A>0?y[A-1]:null,C=A<y.length-1?y[A+1]:null,D=[];if(z.description){if(Array.isArray(z.description))D=z.description;else if("string"==typeof z.description)try{let a=JSON.parse(z.description);D=Array.isArray(a)?a:[{title:"Overview",content:z.description}]}catch{D=[{title:"Overview",content:z.description}]}}let E=(await (0,e.headers)()).get("host")||"demo.webcreationcanada.com",F=E.includes("localhost")?"http":"https",G=`${F}://${E}/blog`,H=`${G}/blogs/${z.slug}`,I=x?.logo_url||`${G}/logo.png`,J=[];if(x?.social_links){let a=x.social_links;a.facebook&&J.push(a.facebook),a.x&&J.push(a.x),a.instagram&&J.push(a.instagram),a.threads&&J.push(a.threads)}let K=[{"@type":"Organization","@id":`${G}/#organization`,name:x?.site_name||"Web Creation Nepal",url:G,logo:{"@type":"ImageObject",url:I},sameAs:J},{"@type":"WebSite","@id":`${G}/#website`,url:G,name:x?.site_name||"Web Creation Nepal",publisher:{"@id":`${G}/#organization`}},{"@type":"BreadcrumbList","@id":`${H}/#breadcrumb`,itemListElement:[{"@type":"ListItem",position:1,name:"Home",item:G},{"@type":"ListItem",position:2,name:"Blogs",item:G},{"@type":"ListItem",position:3,name:z.name,item:H}]},{"@type":"BlogPosting","@id":`${H}/#article`,headline:z.name,description:z.excerpt||z.name,inLanguage:"en-US",mainEntityOfPage:H,datePublished:z.created_at||new Date().toISOString(),dateModified:z.updated_at||new Date().toISOString(),author:{"@type":"Person",name:z.author?.name||"Web Creation Nepal"},publisher:{"@id":`${G}/#organization`},image:z.image?.url||I}];return z.faq&&z.faq.length>0&&K.push({"@type":"FAQPage","@id":`${H}/#faq`,mainEntity:z.faq.map(a=>({"@type":"Question",name:a.question,acceptedAnswer:{"@type":"Answer",text:a.answer}}))}),w.length>0&&K.push({"@type":"ItemList","@id":`${H}/#related-items`,name:"Related Blogs",numberOfItems:w.length,itemListElement:w.map((a,b)=>({"@type":"ListItem",position:b+1,url:`${G}/blogs/${a.slug}`}))}),(0,b.jsxs)("div",{className:"bg-[#fcfdfe] min-h-screen pb-20 font-sans text-zinc-800",children:[(0,b.jsx)("script",{type:"application/ld+json",dangerouslySetInnerHTML:{__html:JSON.stringify({"@context":"https://schema.org","@graph":K})}}),(0,b.jsx)("nav",{className:"py-4 border-b border-zinc-200/60","aria-label":"Breadcrumb",children:(0,b.jsxs)("div",{className:"max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-2 text-xs font-semibold text-zinc-500",children:[(0,b.jsx)(c.default,{href:"/",className:"hover:text-[#2665A3] transition-colors",children:"Home"}),(0,b.jsx)("span",{className:"text-zinc-350",children:"/"}),(0,b.jsx)("span",{className:"text-zinc-450",children:"Blogs"}),(0,b.jsx)("span",{className:"text-zinc-350",children:"/"}),(0,b.jsx)("span",{className:"text-zinc-650 truncate max-w-[200px] sm:max-w-none",children:z.name})]})}),(0,b.jsx)("main",{className:"max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10",children:(0,b.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-12 gap-10",children:[(0,b.jsxs)("div",{className:"lg:col-span-8 flex flex-col",children:[(0,b.jsx)("h1",{className:"text-2xl sm:text-3xl lg:text-[40px] font-bold text-[#252525] lg:leading-[45px] leading-tight tracking-tight mb-6 max-w-full",children:z.name}),(0,b.jsxs)("div",{className:"flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-6 mb-8 border-b border-zinc-200/80",children:[(0,b.jsxs)("div",{className:"flex items-center gap-5",children:[(0,b.jsxs)("div",{className:"flex items-center gap-2.5",children:[(0,b.jsx)("div",{className:"h-6 w-6 rounded-full bg-[#e1ecd9] flex items-center justify-center shrink-0",children:(0,b.jsx)(g.PenTool,{className:"h-3 w-3 text-[#5d8246]"})}),z.author?.slug?(0,b.jsx)(c.default,{href:`/authors/${z.author.slug}`,className:"text-[14px] font-medium text-[#5D5D5D] hover:text-blue-650 transition-colors leading-[24px] cursor-pointer",children:z.author.name}):(0,b.jsx)("span",{className:"text-[14px] font-medium text-[#5D5D5D] leading-[24px]",children:z.author?.name||"Web Creation Nepal"})]}),z.read_time&&(0,b.jsxs)("div",{className:"flex items-center gap-2",children:[(0,b.jsx)("div",{className:"h-6 w-6 rounded-md bg-[#e3ecda] flex items-center justify-center shrink-0",children:(0,b.jsx)(f.Clock,{className:"h-3.5 w-3.5 text-[#5e8347]"})}),(0,b.jsxs)("span",{className:"text-[14px] font-medium text-[#5D5D5D] leading-[24px]",children:[z.read_time," min read"]})]})]}),(0,b.jsx)(j.default,{title:z.name,description:z.excerpt||void 0,url:`https://demo.webcreationcanada.com/blog/blogs/${z.slug}`,authorName:z.author?.name||void 0,readTime:z.read_time||void 0,imageUrl:z.image?.url?s(z.image.url):void 0})]}),z.image?.url&&(0,b.jsx)("div",{className:"relative aspect-[16/9] w-full max-w-full rounded-xl overflow-hidden mb-8 bg-zinc-100 border border-zinc-200/60 shadow-sm",children:(0,b.jsx)(h.default,{src:s(z.image.url),alt:z.image.alt||z.name,fill:!0,priority:!0,loading:"eager",...{fetchPriority:"high"},className:"object-cover"})}),z.excerpt&&(0,b.jsx)("p",{className:"text-zinc-800 text-[17px] font-semibold leading-relaxed mb-8 border-l-4 border-[#2665A3] pl-4 italic",children:z.excerpt}),(0,b.jsx)("div",{className:"space-y-12",children:D.map((a,c)=>{var d;let e=a.title.toLowerCase().replace(/[^\w\s-]/g,"").replace(/\s+/g,"-").replace(/-+/g,"-").trim();return(0,b.jsxs)("article",{id:e,className:"scroll-mt-24",children:[(0,b.jsx)("h2",{className:"text-xl sm:text-[24px] font-semibold text-[#252525] leading-[30px] tracking-tight mb-4 border-b border-zinc-100 pb-2",children:a.title}),(0,b.jsx)("div",{dangerouslySetInnerHTML:{__html:(d=a.content)?d.replace(/<table/gi,'<div class="overflow-x-auto w-full border border-zinc-200 rounded-xl my-6"><table class="min-w-full divide-y divide-zinc-200"').replace(/<\/table>/gi,"</table></div>"):""},className:"blog-content-body text-zinc-750 leading-relaxed text-[15px] sm:text-[16px]"})]},c)})}),z.tags&&z.tags.length>0&&(0,b.jsx)("div",{className:"flex flex-wrap gap-2 mt-8 pt-6 border-t border-zinc-150",children:z.tags.map(a=>(0,b.jsxs)(c.default,{href:`/tags/${a.slug}`,className:"text-xs font-bold text-zinc-650 bg-zinc-100 hover:bg-zinc-200 hover:text-zinc-900 px-3 py-1 rounded-full transition-colors cursor-pointer border border-zinc-200/60",children:["#",a.name]},a.id))}),w.length>0&&(0,b.jsxs)("div",{className:"mt-12 pt-8 border-y border-zinc-200/80 pb-8",children:[(0,b.jsx)("h3",{className:"text-lg font-bold text-zinc-900 mb-6",children:"Related Channels"}),(0,b.jsx)("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-6",children:w.slice(0,2).map(a=>(0,b.jsxs)(c.default,{href:`/blogs/${a.slug}`,className:"group flex gap-4 p-4 rounded-xl border border-zinc-200/80 hover:border-brand-orange bg-[#f4f7fc]/25 hover:bg-[#f4f7fc]/50 transition-all duration-200 cursor-pointer shadow-sm hover:shadow",children:[a.image_url&&(0,b.jsx)("div",{className:"relative w-20 h-20 rounded-lg overflow-hidden shrink-0 bg-zinc-150 border border-zinc-200/40",children:(0,b.jsx)(h.default,{src:s(a.image_url),alt:a.name,fill:!0,className:"object-cover group-hover:scale-102 transition-transform duration-300"})}),(0,b.jsxs)("div",{className:"flex-1 min-w-0 flex flex-col justify-center",children:[(0,b.jsx)("h4",{className:"font-bold text-sm text-zinc-800 group-hover:text-blue-650 leading-snug line-clamp-2 transition-colors",children:a.name}),a.excerpt&&(0,b.jsx)("p",{className:"text-[11px] text-zinc-500 line-clamp-2 mt-1 leading-normal",children:a.excerpt})]})]},a.id))})]}),z.faq&&z.faq.length>0&&(0,b.jsxs)("div",{className:"mt-12 pt-8 border-t border-zinc-200/80",children:[(0,b.jsx)("h3",{className:"text-lg font-bold text-zinc-900 mb-6",children:"Frequently Asked Questions (FAQ)"}),(0,b.jsx)("div",{className:"space-y-4",children:z.faq.map((a,c)=>(0,b.jsxs)("details",{className:"group border border-zinc-250/80 rounded-xl overflow-hidden [&_summary::-webkit-details-marker]:hidden transition-all duration-300",children:[(0,b.jsxs)("summary",{className:"flex items-center justify-between gap-4 p-4 font-bold text-[15px] text-zinc-900 bg-[#f4f7fc]/50 cursor-pointer list-none hover:bg-[#f4f7fc] transition-colors",children:[(0,b.jsx)("span",{children:a.question}),(0,b.jsx)("span",{className:"transition-transform duration-200 group-open:rotate-180 shrink-0",children:(0,b.jsx)("svg",{className:"h-4 w-4 text-zinc-500",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",children:(0,b.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M19 9l-7 7-7-7"})})})]}),(0,b.jsx)("div",{className:"p-4 border-t border-zinc-200/60 text-sm text-zinc-700 leading-relaxed bg-white",children:a.answer})]},c))})]}),(B||C)&&(0,b.jsx)("div",{className:"mt-12 pt-10 border-t border-zinc-200/80",children:(0,b.jsxs)("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-6",children:[B?(0,b.jsxs)(c.default,{href:`/blogs/${B.slug}`,className:"group flex items-center gap-4 p-4 rounded-xl border border-zinc-200/60 bg-[#f4f7fc]/25 hover:bg-[#f4f7fc]/50 hover:border-brand-orange hover:shadow-sm transition-all duration-300 cursor-pointer text-left",children:[B.image_url&&(0,b.jsx)("div",{className:"relative w-16 h-16 sm:w-20 sm:h-20 rounded-lg overflow-hidden shrink-0 bg-zinc-100 border border-zinc-150 shadow-sm",children:(0,b.jsx)(h.default,{src:s(B.image_url),alt:B.name,fill:!0,className:"object-cover group-hover:scale-102 transition-transform duration-300"})}),(0,b.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,b.jsx)("span",{className:"text-[10px] font-bold text-zinc-400 uppercase tracking-widest block mb-1",children:"← Previous Article"}),(0,b.jsx)("h4",{className:"font-bold text-sm sm:text-base text-zinc-800 group-hover:text-blue-650 transition-colors line-clamp-2 leading-snug",children:B.name})]})]}):(0,b.jsx)("div",{className:"hidden sm:block"}),C?(0,b.jsxs)(c.default,{href:`/blogs/${C.slug}`,className:"group flex items-center justify-between gap-4 p-4 rounded-xl border border-zinc-200/60 bg-[#f4f7fc]/25 hover:bg-[#f4f7fc]/50 hover:border-brand-orange hover:shadow-sm transition-all duration-300 cursor-pointer text-right",children:[(0,b.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,b.jsx)("span",{className:"text-[10px] font-bold text-zinc-400 uppercase tracking-widest block mb-1",children:"Next Article →"}),(0,b.jsx)("h4",{className:"font-bold text-sm sm:text-base text-zinc-800 group-hover:text-blue-650 transition-colors line-clamp-2 leading-snug",children:C.name})]}),C.image_url&&(0,b.jsx)("div",{className:"relative w-16 h-16 sm:w-20 sm:h-20 rounded-lg overflow-hidden shrink-0 bg-zinc-100 border border-zinc-150 shadow-sm",children:(0,b.jsx)(h.default,{src:s(C.image_url),alt:C.name,fill:!0,className:"object-cover group-hover:scale-102 transition-transform duration-300"})})]}):(0,b.jsx)("div",{className:"hidden sm:block"})]})}),z.id&&!1!==z.allow_comments&&(0,b.jsx)(i.default,{blogId:z.id,blogSlug:z.slug})]}),(0,b.jsx)("aside",{className:"lg:col-span-4","aria-label":"Sidebar",children:(0,b.jsxs)("div",{className:"sticky top-[107px] z-10 space-y-8",children:[(0,b.jsx)(k.default,{sections:D}),(0,b.jsx)(l.default,{categories:u}),(0,b.jsxs)("div",{className:"relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#1a5276] via-[#1f618d] to-[#2e86c1] text-white p-6 shadow-md border border-blue-900/10 text-center flex flex-col items-center justify-center min-h-[140px] group",children:[(0,b.jsx)("div",{className:"absolute inset-0 opacity-[0.07] pointer-events-none bg-[radial-gradient(circle_at_1px_1px,white_1px,transparent_0)] bg-[size:16px_16px]"}),(0,b.jsx)("p",{className:"text-[10px] font-black uppercase tracking-widest text-blue-200 mb-1",children:"Web Creation Nepal"}),(0,b.jsx)("h4",{className:"text-base font-extrabold mb-3 leading-tight max-w-[240px]",children:"Professional SEO & Web Development Services"}),(0,b.jsx)(c.default,{href:"https://webcreation.com.np",target:"_blank",rel:"noopener noreferrer",className:"inline-flex items-center justify-center px-4 py-2 bg-white hover:bg-zinc-55 text-blue-900 hover:text-blue-950 text-xs font-extrabold uppercase rounded-lg shadow transition-all duration-300 transform group-hover:scale-[1.02]",children:"Get Started"})]})]})})]})}),(0,b.jsx)("style",{dangerouslySetInnerHTML:{__html:`
        .blog-content-body {
          overflow-wrap: break-word;
          word-break: break-word;
        }
        .blog-content-body h1, .blog-content-body h2, .blog-content-body h3, .blog-content-body h4 {
          font-weight: 700;
          color: #18181b;
          margin-top: 1.75rem;
          margin-bottom: 0.75rem;
          line-height: 1.35;
          letter-spacing: -0.01em;
        }
        .blog-content-body h1 {
          font-size: 1.5rem;
        }
        .blog-content-body h2 {
          font-size: 1.35rem;
        }
        .blog-content-body h3 {
          font-size: 1.2rem;
        }
        .blog-content-body h4 {
          font-size: 1.1rem;
        }
        .blog-content-body p {
          margin-bottom: 1.25rem;
          line-height: 1.7;
          color: #27272a;
        }
        .blog-content-body ul {
          list-style: none;
          padding-left: 0;
          margin-bottom: 1.5rem;
        }
        .blog-content-body ul li {
          position: relative;
          padding-left: 1.75rem;
          margin-bottom: 0.65rem;
          color: #27272a;
        }
        .blog-content-body ul li::before {
          content: "";
          position: absolute;
          left: 0.25rem;
          top: 0.6rem;
          width: 0.45rem;
          height: 0.45rem;
          border-radius: 50%;
          background-color: #5e8347;
        }
        .blog-content-body a {
          color: #2563eb !important;
          text-decoration: underline !important;
          font-weight: 600;
          transition: color 0.15s ease-in-out;
        }
        .blog-content-body a:hover {
          color: #1d4ed8 !important;
        }
        .blog-content-body strong {
          color: #18181b;
          font-weight: 700;
        }
        
        /* Premium Table Styles matching first image with responsiveness */
        .blog-content-body table {
          width: 100% !important;
          table-layout: auto !important;
          border-collapse: separate;
          border-spacing: 0;
          margin: 2rem 0;
          font-size: 0.875rem;
          color: #374151;
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          overflow: hidden;
        }
        .blog-content-body table thead tr {
          background-color: #2665A3;
          color: #ffffff;
        }
        .blog-content-body table th {
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          padding: 14px 16px;
          border-bottom: 1px solid #e5e7eb;
          border-right: 1px solid rgba(255, 255, 255, 0.15);
          text-align: center;
          white-space: nowrap !important;
          background-color: #2665A3;
          color: #ffffff;
        }
        .blog-content-body table th:last-child {
          border-right: none;
        }
        .blog-content-body table td {
          padding: 12px 16px;
          border-bottom: 1px solid #e5e7eb;
          border-right: 1px solid #e5e7eb;
          text-align: center;
          vertical-align: middle;
          white-space: nowrap !important;
        }
        .blog-content-body table td:last-child {
          border-right: none;
        }
        .blog-content-body table tr:last-child td {
          border-bottom: none;
        }
        /* Zebra striping */
        .blog-content-body table tbody tr:nth-child(even) td {
          background-color: #f9fafb;
        }
        /* First column cells as side headers */
        .blog-content-body table tbody tr td:first-child,
        .blog-content-body table tbody tr th:first-child {
          background-color: #f3f4f6;
          font-weight: 700;
          color: #1f2937;
          border-right: 1px solid #e5e7eb;
          text-align: center;
        }
        /* Highlighted Column Styles matching the budget column */
        .blog-content-body table th.highlight-column,
        .blog-content-body table tr:first-child th.highlight-column {
          background-color: #709d1e !important;
          color: #ffffff !important;
        }
        .blog-content-body table td.highlight-column {
          border-left: 2px solid #709d1e !important;
          border-right: 2px solid #709d1e !important;
        }
        .blog-content-body table tr:last-child td.highlight-column {
          border-bottom: 2px solid #709d1e !important;
        }
        .blog-content-body table td a {
          display: inline-block;
          padding: 6px 16px;
          background-color: #9ca3af;
          color: #ffffff !important;
          border-radius: 4px;
          font-size: 0.75rem;
          font-weight: 700;
          text-decoration: none !important;
          border-bottom: none;
          transition: background-color 0.2s;
        }
        .blog-content-body table td a:hover {
          background-color: #4b5563;
          color: #ffffff !important;
        }

        /* ── BLOCKQUOTE ── */
        .blog-content-body blockquote {
          display: block !important;
          position: relative !important;
          border-top: 1.5px dashed #d1d5db !important;
          border-bottom: 1.5px dashed #d1d5db !important;
          border-left: none !important;
          border-right: none !important;
          padding: 28px 24px 28px 72px !important;
          margin: 2.5rem 0 !important;
          font-size: 1.05rem !important;
          font-weight: 700 !important;
          color: #1f2937 !important;
          line-height: 1.7 !important;
          font-style: normal !important;
          background: transparent !important;
        }
        .blog-content-body blockquote::before {
          content: "“" !important;
          position: absolute !important;
          left: 10px !important;
          top: 0px !important;
          font-size: 100px !important;
          font-family: Georgia, serif !important;
          color: #d1d5db !important;
          line-height: 1 !important;
          font-weight: 400 !important;
          font-style: normal !important;
        }
        .blog-content-body blockquote p {
          margin: 0 !important;
          display: block !important;
          font-size: 1.05rem !important;
          font-weight: 700 !important;
          color: #1f2937 !important;
          line-height: 1.7 !important;
        }
      `}})]})}a.s(["default",0,v,"generateMetadata",0,u,"generateStaticParams",0,t])},42686,a=>{a.n(a.i(99793))}];

//# sourceMappingURL=src_1vh1io-._.js.map