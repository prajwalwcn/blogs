module.exports=[36527,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_authors_%5Bslug%5D_page_actions_0iz83lc.js.map