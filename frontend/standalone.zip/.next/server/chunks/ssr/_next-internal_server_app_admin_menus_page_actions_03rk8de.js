module.exports=[79305,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_menus_page_actions_03rk8de.js.map