globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/NU9jLqEX-zYd_Z9Ly57rE/_buildManifest.js",
    "static/NU9jLqEX-zYd_Z9Ly57rE/_ssgManifest.js",
    "static/NU9jLqEX-zYd_Z9Ly57rE/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2zjueh7t2vecu.js",
    "static/chunks/0ujm03idtfagv.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/0ssbhdbiu16vp.js",
    "static/chunks/0paxexg6-m0de.js",
    "static/chunks/turbopack-2t7uxxlxbkmz1.js"
  ]
};
