globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/HDW2KFcJ9mv1nI_xQwTn8/_buildManifest.js",
    "static/HDW2KFcJ9mv1nI_xQwTn8/_ssgManifest.js",
    "static/HDW2KFcJ9mv1nI_xQwTn8/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2zjueh7t2vecu.js",
    "static/chunks/1euv48bl2rgvy.js",
    "static/chunks/0ssbhdbiu16vp.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-3t5e54xoyxkke.js"
  ]
};
