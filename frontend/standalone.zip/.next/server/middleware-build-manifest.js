globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/4L0lK0jKlE6AHd9GU23PA/_buildManifest.js",
    "static/4L0lK0jKlE6AHd9GU23PA/_ssgManifest.js",
    "static/4L0lK0jKlE6AHd9GU23PA/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2zjueh7t2vecu.js",
    "static/chunks/1euv48bl2rgvy.js",
    "static/chunks/1abjrzo1nhd4q.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-38asl6e0q1v4d.js"
  ]
};
