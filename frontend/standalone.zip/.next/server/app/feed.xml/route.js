var R=require("../../chunks/[turbopack]_runtime.js")("server/app/feed.xml/route.js")
R.c("server/chunks/[root-of-the-server]__1oxuu-h._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_feed_xml_route_actions_0mikpq1.js")
R.m(59712)
module.exports=R.m(59712).exports
