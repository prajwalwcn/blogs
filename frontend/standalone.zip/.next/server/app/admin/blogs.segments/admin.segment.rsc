1:"$Sreact.fragment"
2:I[39756,["/blog/_next/static/chunks/3aik4k9pqkzly.js","/blog/_next/static/chunks/14mrh2-p_w84d.js","/blog/_next/static/chunks/2mkqny33bit1c.js"],"default"]
3:I[37457,["/blog/_next/static/chunks/3aik4k9pqkzly.js","/blog/_next/static/chunks/14mrh2-p_w84d.js","/blog/_next/static/chunks/2mkqny33bit1c.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"ObPvYqtHLzaueA9KlenBk"}
