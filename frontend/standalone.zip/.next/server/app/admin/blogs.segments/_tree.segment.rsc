:HL["/blog/_next/static/chunks/0ldv0-q3-mggz.css","style"]
:HL["/blog/_next/static/chunks/0-53qi6as7vk0.css","style"]
:HL["/blog/_next/static/media/11beb7591f6e14ea-s.p.3qh2nyhh7vs2v.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/blog/_next/static/media/3a11180d498b75c0-s.p.2028s2bhlck6k.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/blog/_next/static/media/ef1484efef1c9752-s.p.0vtrapzs99yg4.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"admin","param":null,"prefetchHints":0,"slots":{"children":{"name":"blogs","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}},"staleTime":300,"buildId":"IT8fI4A4oS2uHBWX12ep_"}
