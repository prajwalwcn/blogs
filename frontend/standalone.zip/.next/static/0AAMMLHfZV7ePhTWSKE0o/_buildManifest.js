self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/blog/sitemap.xml"
      },
      {
        "source": "/blog/robots.txt"
      },
      {
        "source": "/blog/api/:path*"
      },
      {
        "source": "/blog/storage/:path*"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()